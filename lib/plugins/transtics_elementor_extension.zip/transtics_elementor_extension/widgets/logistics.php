<?php


class Transtics_Logistics_widget extends \Elementor\Widget_Base {

	// Widget Name

	public function get_name() {
		return 'logistics';
	}

	// Widget Titke

	public function get_title() {
		return __( 'Logistics', 'transtics_elementor_extension' );
	}

	// Widget Icon

	public function get_icon() {
		return 'fa fa-truck';
	}

	//	Widget Categories

	public function get_categories() {
		return [ 'transticscategory' ];
	}

	// Register Widget Control

	protected function _register_controls() {

		$this->register_controls();

	}

	// Widget Controls 

	function register_controls() {

		// Main

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Main Section', 'transtics_elementor_extension' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// Title

		$this->add_control(
			'title',
			[
				'label'     => __( 'Title', 'transtics_elementor_extension' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Title', 'transtics_elementor_extension' ),
				'default'     => __( 'Logistics Services', 'transtics_elementor_extension' ),
			]
		);

		// Content

		$this->add_control(
			'content',
			[
				'label'     => __( 'Description', 'transtics_elementor_extension' ),
				'type'      => \Elementor\Controls_Manager::TEXTAREA,
				'rows'		=> '6',
				'placeholder' => __( 'Enter Section Description', 'transtics_elementor_extension' ),
				'default'     => __( 'Solving your supply chain needs from end to end, taking the complexity out of container shipping. We are at the forefront of developing innovation.', 'transtics_elementor_extension' ),
			]
		);

		$this->end_controls_section();

		// Style Section

		$this->start_controls_section(
			'style_section',
			[
				'label' => __( 'Style Section', 'transtics_elementor_extension' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// Background

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Background', 'transtics_elementor_extension' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .logistics',
			]
		);

		// Padding

		$this->add_control(
			'padding',
			[
				'label' => __( 'Padding', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .logistics' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Title

		$this->add_control(
			'title_color',
			[
				'label'     => __( 'Title Color', 'transtics_elementor_extension' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#032c56',
				'selectors' => [
					'{{WRAPPER}} .title' => 'color: {{VALUE}}'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'    => __( 'Title Typography', 'transtics_elementor_extension' ),
				'scheme'   => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .title',
			]
		);

		// Content

		$this->add_control(
			'content_color',
			[
				'label'     => __( 'Description Color', 'transtics_elementor_extension' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#5f6a75',
				'selectors' => [
					'{{WRAPPER}} .description' => 'color: {{VALUE}}'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typography',
				'label'    => __( 'Description Typography', 'transtics_elementor_extension' ),
				'scheme'   => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .description',
			]
		);

		// Tab Title

		$this->add_control(
			'tab_title_color',
			[
				'label'     => __( 'Tab Title Color', 'transtics_elementor_extension' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#032c56',
				'selectors' => [
					'{{WRAPPER}} .nav-item' => 'color: {{VALUE}}'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'tab_title_typography',
				'label'    => __( 'Tab Title Typography', 'transtics_elementor_extension' ),
				'scheme'   => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .nav-item',
			]
		);

		// Tab Item Title Number

		$this->add_control(
			'tab_title_number_color',
			[
				'label'     => __( 'Title Number Color', 'transtics_elementor_extension' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FF0000',
				'selectors' => [
					'{{WRAPPER}} .number' => 'color: {{VALUE}}'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'tab_title_number_typography',
				'label'    => __( 'Title Number Typography', 'transtics_elementor_extension' ),
				'scheme'   => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .number',
			]
		);

		// Tab Item Title Bold

		$this->add_control(
			'tab_title_bold_color',
			[
				'label'     => __( 'Bold Title Color', 'transtics_elementor_extension' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#032c56',
				'selectors' => [
					'{{WRAPPER}} .bold' => 'color: {{VALUE}}'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'tab_title_bold_typography',
				'label'    => __( 'Bold Title Typography', 'transtics_elementor_extension' ),
				'scheme'   => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .bold',
			]
		);

		// Tab Item Title Normal

		$this->add_control(
			'tab_title_normal_color',
			[
				'label'     => __( 'Normal Title Color', 'transtics_elementor_extension' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#032c56',
				'selectors' => [
					'{{WRAPPER}} .simple' => 'color: {{VALUE}}'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'tab_title_normal_typography',
				'label'    => __( 'Normal Title Typography', 'transtics_elementor_extension' ),
				'scheme'   => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .simple',
			]
		);

		// Tab Content

		$this->add_control(
			'tab_content_color',
			[
				'label'     => __( 'Content Color', 'transtics_elementor_extension' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#5f6a75',
				'selectors' => [
					'{{WRAPPER}} .content' => 'color: {{VALUE}}'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'tab_content_typography',
				'label'    => __( 'Content Typography', 'transtics_elementor_extension' ),
				'scheme'   => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .content',
			]
		);

		$this->end_controls_section();

		// Tab Section One

		$this->start_controls_section(
			'tab_one_section',
			[
				'label' => __( 'Tab One', 'transtics_elementor_extension' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// Tab Title

		$this->add_control(
			'tab_one_title',
			[
				'label'     => __( 'Title', 'transtics_elementor_extension' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Title', 'transtics_elementor_extension' ),
				'default'     => __( 'Business Logistics', 'transtics_elementor_extension' ),
			]
		);

		// Tab Icon

		$this->add_control(
			'tab_one_icon',
			[
				'label' => __( 'Icon', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::ICON,
				'default' => 'fa fa-bus',
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'tab_one_image',
			[
				'label' => __( 'Image', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		// Title Number

		$repeater->add_control(
			'tab_one_title_number',
			[
				'label'     => __( 'Title Number', 'transtics_elementor_extension' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Number', 'transtics_elementor_extension' ),
				'default'     => __( '0.1', 'transtics_elementor_extension' ),
			]
		);

		// Title Bold

		$repeater->add_control(
			'tab_one_title_bold',
			[
				'label'     => __( 'Bold Title', 'transtics_elementor_extension' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Bold Title', 'transtics_elementor_extension' ),
				'default'     => __( 'Air', 'transtics_elementor_extension' ),
			]
		);

		// Title Bold

		$repeater->add_control(
			'tab_one_title_normal',
			[
				'label'     => __( 'Normal Title', 'transtics_elementor_extension' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Normal Title', 'transtics_elementor_extension' ),
				'default'     => __( 'Frieght', 'transtics_elementor_extension' ),
			]
		);

		// Tab Content

		$repeater->add_control(
			'tab_one_content',
			[
				'label'     => __( 'Content', 'transtics_elementor_extension' ),
				'type'      => \Elementor\Controls_Manager::TEXTAREA,
				'rows'		=> '6',
				'placeholder' => __( 'Enter Section Description', 'transtics_elementor_extension' ),
				'default'     => __( 'We offer a Global Logistics Network with our worldwide offices', 'transtics_elementor_extension' ),
			]
		);

		$repeater->add_control(
			'tab_one_url',
			[
				'label'     => __( 'Item Url', 'transtics_elementor_extension' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'transtics_elementor_extension' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->add_control(
			'tab_one_list',
			[
				'label' => __( 'Logistics Item', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		$this->end_controls_section();

		// Tab Section Two

		$this->start_controls_section(
			'tab_two_section',
			[
				'label' => __( 'Tab Two', 'transtics_elementor_extension' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// Tab Title

		$this->add_control(
			'tab_two_title',
			[
				'label'     => __( 'Title', 'transtics_elementor_extension' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Title', 'transtics_elementor_extension' ),
				'default'     => __( 'Military Logistics', 'transtics_elementor_extension' ),
			]
		);

		// Tab Icon

		$this->add_control(
			'tab_two_icon',
			[
				'label' => __( 'Icon', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::ICON,
				'default' => 'fa fa-truck',
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'tab_two_image',
			[
				'label' => __( 'Image', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		// Title Number

		$repeater->add_control(
			'tab_two_title_number',
			[
				'label'     => __( 'Title Number', 'transtics_elementor_extension' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Number', 'transtics_elementor_extension' ),
				'default'     => __( '0.1', 'transtics_elementor_extension' ),
			]
		);

		// Title Bold

		$repeater->add_control(
			'tab_two_title_bold',
			[
				'label'     => __( 'Bold Title', 'transtics_elementor_extension' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Bold Title', 'transtics_elementor_extension' ),
				'default'     => __( 'Air', 'transtics_elementor_extension' ),
			]
		);

		// Title Bold

		$repeater->add_control(
			'tab_two_title_normal',
			[
				'label'     => __( 'Normal Title', 'transtics_elementor_extension' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Normal Title', 'transtics_elementor_extension' ),
				'default'     => __( 'Frieght', 'transtics_elementor_extension' ),
			]
		);

		// Tab Content

		$repeater->add_control(
			'tab_two_content',
			[
				'label'     => __( 'Content', 'transtics_elementor_extension' ),
				'type'      => \Elementor\Controls_Manager::TEXTAREA,
				'rows'		=> '6',
				'placeholder' => __( 'Enter Section Description', 'transtics_elementor_extension' ),
				'default'     => __( 'We offer a Global Logistics Network with our worldwide offices', 'transtics_elementor_extension' ),
			]
		);

		$repeater->add_control(
			'tab_two_url',
			[
				'label'     => __( 'Item Url', 'transtics_elementor_extension' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'transtics_elementor_extension' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->add_control(
			'tab_two_list',
			[
				'label' => __( 'Logistics Item', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		$this->end_controls_section();

		// Tab Section Three

		$this->start_controls_section(
			'tab_three_section',
			[
				'label' => __( 'Tab Three', 'transtics_elementor_extension' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// Tab Title

		$this->add_control(
			'tab_three_title',
			[
				'label'     => __( 'Title', 'transtics_elementor_extension' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Title', 'transtics_elementor_extension' ),
				'default'     => __( 'Event Logistics', 'transtics_elementor_extension' ),
			]
		);

		// Tab Icon

		$this->add_control(
			'tab_three_icon',
			[
				'label' => __( 'Icon', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::ICON,
				'default' => 'fa fa-calendar',
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'tab_three_image',
			[
				'label' => __( 'Image', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		// Title Number

		$repeater->add_control(
			'tab_three_title_number',
			[
				'label'     => __( 'Title Number', 'transtics_elementor_extension' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Number', 'transtics_elementor_extension' ),
				'default'     => __( '0.1', 'transtics_elementor_extension' ),
			]
		);

		// Title Bold

		$repeater->add_control(
			'tab_three_title_bold',
			[
				'label'     => __( 'Bold Title', 'transtics_elementor_extension' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Bold Title', 'transtics_elementor_extension' ),
				'default'     => __( 'Air', 'transtics_elementor_extension' ),
			]
		);

		// Title Bold

		$repeater->add_control(
			'tab_three_title_normal',
			[
				'label'     => __( 'Normal Title', 'transtics_elementor_extension' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Normal Title', 'transtics_elementor_extension' ),
				'default'     => __( 'Frieght', 'transtics_elementor_extension' ),
			]
		);

		// Tab Content

		$repeater->add_control(
			'tab_three_content',
			[
				'label'     => __( 'Content', 'transtics_elementor_extension' ),
				'type'      => \Elementor\Controls_Manager::TEXTAREA,
				'rows'		=> '6',
				'placeholder' => __( 'Enter Section Description', 'transtics_elementor_extension' ),
				'default'     => __( 'We offer a Global Logistics Network with our worldwide offices', 'transtics_elementor_extension' ),
			]
		);

		$repeater->add_control(
			'tab_three_url',
			[
				'label'     => __( 'Item Url', 'transtics_elementor_extension' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'transtics_elementor_extension' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->add_control(
			'tab_three_list',
			[
				'label' => __( 'Logistics Item', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		$this->end_controls_section();

	}

	// Widget Render Output

	protected function render() {

		$settings   = $this->get_settings_for_display();
		?>
		<!-- Logistics -->
		<section class="logistics">
		    <div class="container">
		        <div class="row">
		            <div class="col-md-12">
		                <h1 class="title"><?php echo $settings['title'] ?></h1>
		                <p class="description"><?php echo $settings['content'] ?></p>
		            </div>
		        </div>
		        <div class="row">
		            <div class="col-md-12">
		                <nav>
		                    <div class="nav nav-tabs" id="nav-tab1" role="tablist">
		                        <a class="nav-item nav-link nav-one active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true"><span><i class="<?php echo $settings['tab_one_icon'] ?>"></i></span> <?php echo $settings['tab_one_title'] ?></a>
		                        <a class="nav-item nav-link nav-two" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false"><span><i class="<?php echo $settings['tab_two_icon'] ?>"></i></span> <?php echo $settings['tab_two_title'] ?></a>
		                        <a class="nav-item nav-link nav-three" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false"><span><i class="<?php echo $settings['tab_three_icon'] ?>"></i></span> <?php echo $settings['tab_three_title'] ?></a>
		                    </div>
		                </nav>
		                <div class="tab-content" id="nav-tabContent">
		                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
		                        <div class="owl-carousel owl-theme" id="logistics-carousel-one">
		                            <?php if ( $settings['tab_one_list'] ) {
				                		foreach (  $settings['tab_one_list'] as $item ) {
				                	?>
				                	<?php
				                		$tab_one_target = $item['tab_one_url']['is_external'] ? ' target="_blank"' : '';
										$tab_one_nofollow = $item['tab_one_url']['nofollow'] ? ' rel="nofollow"' : '';
				                	?>
		                            <div class="item">
		                                <div class="item-wrapper">
		                                    <img src="<?php echo $item['tab_one_image']['url'] ?>" alt="Image">
		                                    <div class="link-icon">
		                                        <a href="<?php echo $item['tab_one_url']['url'] ?>"  <?php echo $tab_one_target  ?>  <?php $tab_one_nofollow ?>><i class="fas fa-link"></i></a>
		                                    </div>
		                                </div>
		                                <h4>
		                                	<span class="number"><?php echo $item['tab_one_title_number'] ?></span> 
		                                	<span class="bold"><?php echo $item['tab_one_title_bold'] ?></span> 
		                                	<span class="simple"><?php echo $item['tab_one_title_normal'] ?></span>
		                                </h4>
		                                <p class="content"><?php echo $item['tab_one_content'] ?></p>
		                            </div>
		                            <?php } } ?>
		                        </div>
		                    </div>
		                    <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
		                        <div class="owl-carousel owl-theme" id="logistics-carousel-two">
		                        	<?php if ( $settings['tab_two_list'] ) {
				                		foreach (  $settings['tab_two_list'] as $item ) {
				                	?>
				                	<?php
				                		$tab_two_target = $item['tab_two_url']['is_external'] ? ' target="_blank"' : '';
										$tab_two_nofollow = $item['tab_two_url']['nofollow'] ? ' rel="nofollow"' : '';
				                	?>
		                            <div class="item">
		                                <div class="item-wrapper">
		                                    <img src="<?php echo $item['tab_two_image']['url'] ?>" alt="Image">
		                                    <div class="link-icon">
		                                        <a href="<?php echo $item['tab_two_url']['url'] ?>"  <?php echo $tab_two_target  ?>  <?php $tab_two_nofollow ?>><i class="fas fa-link"></i></a>
		                                    </div>
		                                </div>
		                                <h4>
		                                	<span class="number"><?php echo $item['tab_two_title_number'] ?></span> 
		                                	<span class="bold"><?php echo $item['tab_two_title_bold'] ?></span> 
		                                	<span class="simple"><?php echo $item['tab_two_title_normal'] ?></span>
		                                </h4>
		                                <p class="content"><?php echo $item['tab_two_content'] ?></p>
		                            </div>
		                            <?php } } ?>
		                        </div>
		                    </div>
		                    <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
		                        <div class="owl-carousel owl-theme" id="logistics-carousel-three">
		                        	<?php if ( $settings['tab_three_list'] ) {
				                		foreach (  $settings['tab_three_list'] as $item ) {
				                	?>
				                	<?php
				                		$tab_three_target = $item['tab_three_url']['is_external'] ? ' target="_blank"' : '';
										$tab_three_nofollow = $item['tab_three_url']['nofollow'] ? ' rel="nofollow"' : '';
				                	?>
		                            <div class="item">
		                                <div class="item-wrapper">
		                                    <img src="<?php echo $item['tab_three_image']['url'] ?>" alt="Image">
		                                    <div class="link-icon">
		                                        <a href="<?php echo $item['tab_three_url']['url'] ?>"  <?php echo $tab_three_target  ?>  <?php $tab_three_nofollow ?>><i class="fas fa-link"></i></a>
		                                    </div>
		                                </div>
		                                <h4>
		                                	<span class="number"><?php echo $item['tab_three_title_number'] ?></span> 
		                                	<span class="bold"><?php echo $item['tab_three_title_bold'] ?></span> 
		                                	<span class="simple"><?php echo $item['tab_three_title_normal'] ?></span>
		                                </h4>
		                                <p class="content"><?php echo $item['tab_three_content'] ?></p>
		                            </div>
		                            <?php } } ?>
		                        </div>
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
		</section>
		<!-- Logistics /-->
		<?php
	}

}
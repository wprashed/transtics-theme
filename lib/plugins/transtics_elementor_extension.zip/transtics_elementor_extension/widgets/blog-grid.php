<?php


class Transtics_BlogGrid_widget extends \Elementor\Widget_Base {

	// Widget Name

	public function get_name() {
		return 'blog-grid';
	}

	// Widget Titke

	public function get_title() {
		return __( 'Blog Grid', 'transtics_elementor_extension' );
	}

	// Widget Icon

	public function get_icon() {
		return 'fa fa-file-text-o';
	}

	//	Widget Categories

	public function get_categories() {
		return [ 'transticscategory' ];
	}

	// Register Widget Control

	protected function _register_controls() {

		$this->register_controls();

	}

	// Widget Controls 

	function register_controls() {

		$args = array(
			'orderby' => 'name',
			'order' => 'ASC'
		);

		$categories=get_categories($args);
		$cate_array = array();
		$arrayCateAll = array( 'all' => 'All categories ' );
		if ($categories) {
			foreach ( $categories as $cate ) {
				$cate_array[$cate->cat_name] = $cate->slug;
			}
		} else {
			$cate_array["No content Category found"] = 0;
		}

		// Controls

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Blog Controls', 'transtics_elementor_extension' ),
			]
		);

		// Background

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Background', 'transtics_elementor_extension' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .blogs',
			]
		);

		// Padding

		$this->add_control(
			'padding',
			[
				'label' => __( 'Padding', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .blogs' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Category

		$this->add_control(
			'category',
			[
				'label' => __( 'Category', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'all',
				'options' => array_merge($arrayCateAll,$cate_array),
			]
		);

		// Total Count

		$this->add_control(
			'total_count',
			[
				'label' => __( 'Total Post', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 3,
			]
		);

		// Order By

		$this->add_control(
			'order_by',
			[
				'label' => __('Order By', 'transtics_elementor_extension'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'desc',
				'options' => [
					'asc' => __('ASC', 'transtics_elementor_extension'),
					'desc' => __('DESC', 'transtics_elementor_extension'),
				]
			]
		);

		// Meta Condition

		$this->add_control(
			'show_author',
			[
				'label' => __( 'Show Author', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'transtics_elementor_extension' ),
				'label_off' => __( 'Hide', 'transtics_elementor_extension' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_category',
			[
				'label' => __( 'Show Date', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'transtics_elementor_extension' ),
				'label_off' => __( 'Hide', 'transtics_elementor_extension' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		// Blog Title Color

		$this->add_control(
			'blog_title_color',
			[
				'label' => __( 'Title Color', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} h3.btitle a' => 'color : {{VALUE}} ;'
				],
				'default' => '#032c56'
				
			]
		);
		$this->add_control(
			'title_color_hover',
			[
				'label' => __( 'Title Color Hover', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} h3.btitle a:hover' => 'color : {{VALUE}} ;'
				],
				'default' => '#FF0000',
				'separator' => 'after',
				
			]
		);

		// Meta Color

		$this->add_control(
			'meta_color',
			[
				'label' => __( 'Author & Date Color', 'transtics_elementor_extension' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .meta' => 'color : {{VALUE}}!important;'
				],
				'default' => '#878d9c'
				
			]
		);


		$this->end_controls_section();

	}

	// Widget Render Output

	protected function render() {

		$settings   = $this->get_settings_for_display();

		$category = $settings['category'];
		$total_count = $settings['total_count'];
		$order = $settings['order_by'];

		$args = [];
		if ($category == 'all') {
			$args=[
				'post_type' => 'post',
				'posts_per_page' => $total_count,
				'order' => $order,
			];
		} else {
			$args=[
				'post_type' => 'post', 
				'category_name'=>$category,
				'posts_per_page' => $total_count,
				'order' => $order,
			];
		}

		$blog = new \WP_Query($args);

		?>
		<!-- Blog -->
		<section class="blogs">
		    <div class="container">
		        <div class="row">
		        	<?php
						if($blog->have_posts()) : while($blog->have_posts()) : $blog->the_post();
					?>
		            <div class="col-lg-4 col-md-6 col-sm-12 col-12">
		                <div class="blog-box">
		                	<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail("transtics-news-grid"); ?></a>
		                    <h3 class="btitle"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		                    <h5 class="meta">
		                    	<?php if ($settings['show_author']) : ?>
		                    	<strong>By:</strong> <?php the_author(); ?> | 
		                    	<?php endif ?>
			                    <?php 
						            $archive_year  = get_the_time('y'); 
						            $archive_month = get_the_time('m'); 
						            $archive_day   = get_the_time('d'); 
					            ?>
					            <?php if ($settings['show_category']) : ?>
		                    	<?php echo esc_html( get_the_date() ); ?> <?php the_time('g:i a'); ?>
		                    	<?php endif ?>
		                    </h5>
		                </div>
		            </div>
		            <?php
						endwhile; endif; wp_reset_postdata();
					?>
		        </div>
		    </div>
		</section>
		<!-- Blog /-->
		<?php
	}
	}